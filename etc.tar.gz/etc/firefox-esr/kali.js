/* Kali default settings */
/* Everything is handled through policies.json */

/* Use CSD titlebars */
pref("browser.tabs.inTitlebar", 1);
